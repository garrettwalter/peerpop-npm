# peerpop

The official [PeerPop](https://peerpop.io) Node.js SDK. 

V1 offers Webhook verification signatures in one line.

For more information on webhooks, see the [PeerPop Webhook documentation](https://docs.peerpop.io/beta-features/webhook).

## Install

```bash
npm install peerpop
```

## Webhook verification

### One-line verify

Use the **raw** request body (the exact string or buffer as received) and the `X-Webhook-Signature` header:

```js
const peerpop = require("peerpop");

// In your webhook handler (you must have access to the raw body)
const payload = peerpop.webhook.verify(rawBody, req.headers["x-webhook-signature"], process.env.PEERPOP_API_KEY);
// payload is { phone, email, action, amount, event, metadata }
```

If the signature is missing (you didn’t set a secret), invalid, or expired, `verify()` throws. Catch and return 400:

```js
try {
  const payload = peerpop.webhook.verify(rawBody, req.headers["x-webhook-signature"], process.env.PEERPOP_API_KEY);
  // use payload
} catch (err) {
  res.status(400).send(err.message);
}
```

Errors have `err.code` set to `PEERPOP_WEBHOOK_INVALID` or `PEERPOP_WEBHOOK_EXPIRED`.

### Express (raw body required)

Verification must run on the **raw** body. Use `express.raw()` for the webhook route so the body isn’t parsed as JSON before verification:

```js
const express = require("express");
const peerpop = require("peerpop");

const app = express();

app.post(
  "/webhook",
  express.raw({ type: "application/json" }),
  peerpop.webhook.middleware(process.env.PEERPOP_API_KEY),
  (req, res) => {
    const payload = req.webhookPayload; // already verified and parsed
    console.log(payload);
    res.send("OK");
  }
);
```

If verification fails, the middleware responds with 400 and does not call your route.

## API

- **`peerpop.webhook.verify(rawBody, signatureHeader, secret)`**  
  Returns the parsed payload object, or throws if signature is invalid/expired. Use when you have the raw body string (or buffer converted to string).

- **`peerpop.webhook.middleware(secret)`**  
  Express middleware that verifies the request and sets `req.webhookPayload`. Use with `express.raw({ type: "application/json" })` on that route.

## Signature format

PeerPop sends `X-Webhook-Signature: t=<unix_timestamp>,v1=<hmac_sha256_hex>`. The HMAC is over `timestamp + "." + rawBody` with your webhook secret. Signatures older than 5 minutes are rejected (replay protection).
